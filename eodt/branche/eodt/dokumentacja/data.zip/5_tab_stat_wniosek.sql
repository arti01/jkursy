USE [EOD]
GO

/****** Object:  Table [esk].[stat_wniosek]    Script Date: 11/29/2012 21:19:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [esk].[stat_wniosek](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[st_opis] [nchar](100) NULL,
	[st_skrot] [char](2) NULL,
	[st_kolor] [char](6) NULL,
 CONSTRAINT [PK_stat_wniosek] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


