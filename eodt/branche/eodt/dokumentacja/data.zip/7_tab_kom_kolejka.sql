USE [EOD]
GO

/****** Object:  Table [esk].[kom_kolejka]    Script Date: 11/29/2012 21:18:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [esk].[kom_kolejka](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[adres_list] [text] NULL,
	[tresc] [text] NULL,
	[status] [int] NULL,
 CONSTRAINT [PK_kom_kolejka] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO


