USE [EOD]
GO

/****** Object:  Table [esk].[szab_wniosek]    Script Date: 11/29/2012 21:19:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [esk].[szab_wniosek](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[nazwa] [nchar](50) NULL,
	[schemat] [text] NULL,
 CONSTRAINT [PK_szab_wniosek] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO


