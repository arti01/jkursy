USE [EOD]
GO

/****** Object:  Table [esk].[obieg]    Script Date: 11/29/2012 21:18:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [esk].[obieg](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[szablon_id] [bigint] NULL,
	[user_id] [bigint] NULL,
	[akc_user_id] [bigint] NULL,
	[status] [bigint] NULL,
	[data_utw] [datetime] NULL,
	[data_ost_akcji] [datetime] NULL,
	[data_akc] [datetime] NULL,
	[tresc] [text] NULL,
	[historia] [text] NULL,
	[nr_wniosku] [char](22) NULL,
 CONSTRAINT [PK_obieg] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [esk].[obieg]  WITH CHECK ADD  CONSTRAINT [FK_obieg_obieg] FOREIGN KEY([id])
REFERENCES [esk].[obieg] ([id])
GO

ALTER TABLE [esk].[obieg] CHECK CONSTRAINT [FK_obieg_obieg]
GO

ALTER TABLE [esk].[obieg]  WITH CHECK ADD  CONSTRAINT [FK_obieg_stat_wniosek] FOREIGN KEY([status])
REFERENCES [esk].[stat_wniosek] ([id])
GO

ALTER TABLE [esk].[obieg] CHECK CONSTRAINT [FK_obieg_stat_wniosek]
GO

ALTER TABLE [esk].[obieg]  WITH CHECK ADD  CONSTRAINT [FK_obieg_szab_wniosek] FOREIGN KEY([szablon_id])
REFERENCES [esk].[szab_wniosek] ([id])
GO

ALTER TABLE [esk].[obieg] CHECK CONSTRAINT [FK_obieg_szab_wniosek]
GO


